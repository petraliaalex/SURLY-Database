
public interface Icommand {

	 void run() ;
	 
}
