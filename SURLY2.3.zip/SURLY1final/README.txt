Command line to run: 
/$ javac mainMethod.java
/$ java mainMethod.java SURLY-input.txt > output.txt
		

mainMethod:
--takes in one arument which will be the name of the file in .txt format
--creates a Scanner object from that file and sends the Scanner object to the parser class

Input: SURLY-input.txt
Output: output.txt

edge cases:
--solved:
  --inserting to a relation that doesn't exist
  --inserting with the wrong schema format
  --creating a relation with incorrect schema format
  --creating duplicate relations
--unsolved:
  --inserting duplicate inserts

